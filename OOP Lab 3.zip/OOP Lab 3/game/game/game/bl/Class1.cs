﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game.bl
{
        class Player
        {
            public int PX;
            public int PY;

        public Player()
        {

        }
        public Player(int PX,int PY)
        {
            this.PX = PX;
            this.PY = PY;
        }



        public void printspaceship(char[,] player_space_ship, Player p1)
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            for (int rows = 0; rows < 7; rows++)
            {
                Console.SetCursorPosition(p1.PX, p1.PY + rows);
                for (int col = 0; col < 13; col++)
                {
                    Console.Write(player_space_ship[rows, col]);
                }
                Console.WriteLine();
            }
        }
        public void erasespaceship(Player p)
        {
            for (int rows = 0; rows < 7; rows++)
            {
                Console.SetCursorPosition(p.PX, p.PY + rows);
                for (int col = 0; col < 13; col++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }

        public void moveplayerleft(char[,] Maze, char[,] enemy1_space_ship, char[,] player_space_ship, ref bool gamerunning, Player p1, Enemy e1,int enemy1counter)
        {
            enemy1counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze, ref gamerunning, e1);
            }

            char next = Maze[p1.PY, p1.PX - 1];
            if (next == ' ')
            {
                erasespaceship(p1);
                p1.PX--;
                printspaceship(player_space_ship, p1);
            }
        }
        public void moveplayerright(char[,] Maze, char[,] enemy1_space_ship, char[,] player_space_ship, ref bool gamerunning, Player p1, Enemy e1, int enemy1counter)
        {
            enemy1counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze, ref gamerunning, e1);
            }

            char next = Maze[p1.PY, p1.PX + 13];
            if (next == ' ')
            {
                erasespaceship(p1);
                p1.PX++;
                printspaceship(player_space_ship, p1);
            }
        }
        public void moveplayerup(char[,] Maze, char[,] enemy1_space_ship, char[,] player_space_ship, ref bool gamerunning, Player p1, Enemy e1, int enemy1counter)
        {
            enemy1counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze, ref gamerunning, e1);
            }

            char next = Maze[p1.PY - 1, p1.PX];
            if (next == ' ')
            {
                erasespaceship(p1);
                p1.PY--;
                printspaceship(player_space_ship, p1);
            }
        }
        public void moveplayerdown(char[,] Maze, char[,] enemy1_space_ship, char[,] player_space_ship, ref bool gamerunning, Player p1, Enemy e1, int enemy1counter)
        {
            enemy1counter++;
            if (enemy1counter % 3 == 0)
            {
                moveenemy1(enemy1_space_ship, Maze, ref gamerunning, e1);
            }
            char next = Maze[p1.PY + 7, p1.PX];
            if (next == ' ')
            {
                erasespaceship(p1);
                p1.PY++;
                printspaceship(player_space_ship, p1);
            }
        }

        public void printenemy1(char[,] enemy1_space_ship, Enemy e1)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            for (int rows = 0; rows < 5; rows++)
            {
                Console.SetCursorPosition(e1.E1X, e1.E1Y + rows);
                for (int col = 0; col < 7; col++)
                {
                    Console.Write(enemy1_space_ship[rows, col]);
                }
                Console.WriteLine();
            }
        }
        public void eraseenemy1(Enemy e)
        {
            for (int rows = 0; rows < 5; rows++)
            {
                Console.SetCursorPosition(e.E1X, e.E1Y + rows);
                for (int col = 0; col < 7; col++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }


        public void moveenemy1(char[,] enemy1_space_ship, char[,] Maze, ref bool gamerunning, Enemy e1)
        {

            if (e1.direction == "down")
            {
                char next = Maze[e1.E1Y + 5, e1.E1X];
                if (next == ' ')
                {
                    eraseenemy1(e1);
                    e1.E1Y++;
                    printenemy1(enemy1_space_ship, e1);
                }
                if (next == '+')
                {
                    eraseenemy1(e1);
                    e1.E1Y = 1;
                    printenemy1(enemy1_space_ship, e1);
                }
                else
                {

                    for (int i = 0; i < 6; i++)
                    {
                        next = Maze[e1.E1Y + 5, e1.E1X + i];
                        if (next == '_' || next == '\\' || next == '/' || next == '|')
                        {
                            gamerunning = false;

                            /*      loselife();
                                  updatelives();*/
                        }
                    }
                }
            }
        }

    }




    class Enemy
        {
            public int E1X;
            public int E1Y;
            public string direction;

        public Enemy()
        { 
        }
        public Enemy(int E1X,int E1Y,string direction)
        {
            this.E1X = E1X;
            this.E1Y = E1Y;
            this.direction = direction;

        }


  

    }
    class Bullet
        {
            public int bulletx;
            public int bullety;
            public bool isbulletactive;
        }

    

}

