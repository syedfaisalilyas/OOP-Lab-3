﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3.bl
{
    class ClockType
    {
        public ClockType()
        {
            hours = 0;
            minutes = 0;
            seconds = 0;
        }

        public ClockType(int h)
        {
            hours = h;
        }
        public ClockType(int h, int m)
        {
            hours = h;
            minutes = m;
        }
        public ClockType(int h, int m, int s)
        {
            hours = h;
            minutes = m;
            seconds = s;
        }   

        public int ellapsedSeconds(ClockType ct)
        {
            
           return ( (ct.hours*60*60)+(ct.minutes*60)+ct.seconds);
        }

        public void EllapsedTime(int h, int m, int s,ClockType curr_t)
        {
           int es;
           int em;
           int eh;

           if(curr_t.seconds>s)
            {
            es = curr_t.seconds-s;
            }
           else
            {
               es = 60 + (curr_t.seconds-s);
                if(es<1)
                {
                    m--;
                }

            }

           if(curr_t.minutes>m)
            {
                em = curr_t.minutes -m;
            }
           else
            {
                em = 60 + (curr_t.minutes-m);
                if(em<1)
                {
                    h--;
                }

            }

            Math.Abs(eh= curr_t.hours-h);
             
            Console.WriteLine("Elapsed Time: " + eh+":"+em+":"+es);
           
        }

        public int remainingTime(ClockType temp)
        {
            int rtime=0;
            return rtime = ((24-temp.hours)*360+(60-temp.minutes)*60+(60-temp.seconds));
        }

        public void timediffereence(ClockType temp)
        {
            int difference = remainingTime(temp) - ellapsedSeconds(temp);
            Console.WriteLine("The time difference is:" +Math.Abs( difference));
            int h= difference/3600;
            int e = difference%3600;
            int m = e/60;
            int s = e%60;
           Console.WriteLine(Math.Abs(h)+":"+Math.Abs(m)+":"+Math.Abs(s));

        }
        public void incrementsecond()
        {
            seconds++;
        }
        public void incrementminutes()
        {
            minutes++;
        }
        public void incrementhours()
        {
            hours++;
        }

        public void printTime()
        {
            Console.WriteLine(hours + " " + minutes + " " + seconds);
        }
        public bool isEqual(int h,int m,int s)
        {
            if(hours == h && minutes == m && seconds == s)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool isEqual(ClockType temp)
        {
            if (hours == temp.hours && minutes == temp.minutes && seconds == temp.seconds)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int hours;
        public int minutes;
        public int seconds;


    }
}
