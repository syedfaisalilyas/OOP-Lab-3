﻿using lab3.bl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3
{
    class Program
    {
        static void Main(string[] args)
        {
            ClockType empty_time = new ClockType();
            Console.WriteLine("Empty time:");
            empty_time.printTime();

            ClockType hour_time = new ClockType(8);
            Console.WriteLine("Hour time:");
            hour_time.printTime();

            ClockType minute_time = new ClockType(8,10);
            Console.WriteLine("Minute time:");
            minute_time.printTime();

            ClockType full_time = new ClockType();
            Console.WriteLine("Second time:");
            full_time.printTime();

            full_time.incrementsecond();
            Console.WriteLine("Full time(Increment seconds):");
            full_time.printTime();

             full_time.incrementminutes();
            Console.WriteLine("Full time(Increment Minutes):");
            full_time.printTime();

             full_time.incrementhours();
            Console.WriteLine("Full time(Increment Hours):");
            full_time.printTime();

            bool flag = full_time.isEqual(9, 11, 11);
            Console.WriteLine("Falg:" + flag);

            ClockType cmp = new ClockType(10, 12, 1);
            flag = full_time.isEqual(cmp);
            Console.WriteLine("Object Flag:" + flag);

            ClockType elapsedseconds = new ClockType();
            int t =  elapsedseconds.ellapsedSeconds(full_time);
            Console.WriteLine("Elapsed Seconds:"+ t);

            ClockType ellapsed_time = new ClockType();
            ellapsed_time.EllapsedTime(0,0,0,full_time);
            
           full_time.timediffereence(cmp);

            Console.Read();
        }
    }
}
