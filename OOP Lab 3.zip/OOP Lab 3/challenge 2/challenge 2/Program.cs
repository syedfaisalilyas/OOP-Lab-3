﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int option=0;
            List<Product> product_list = new List<Product>();
            while(option!=6)
            {
                Console.Clear();
                Menu();
                Console.WriteLine("Enter option:");
                option = int.Parse(Console.ReadLine());
                if (option == 1)
                {
                    Add_Product(product_list);
                    Console.ReadKey();
                }
                else if (option == 2)
                {
                    view_products(product_list);
                    Console.ReadKey();

                }
                else if (option == 3)
                {
                    Product np = find_highest_price(product_list);
                    Console.WriteLine("The product is " + np.product_name + "with the highest price " + np.product_price);
                    Console.ReadKey();

                }
                else if (option == 4)
                {
                    view_sales_tax(product_list);
                    Console.ReadKey();

                }
                else if(option == 5)
                {
                    product_to_b_ordered(product_list);
                    Console.ReadKey();

                }
                else if(option<1 || option >6)
                {
                    Console.WriteLine("Invalid Choice!");
                    Console.ReadKey();

                }

            }
                Console.Read();

        }
            static void Menu()
            {
                Console.WriteLine("1. Add Product");
                Console.WriteLine("2. View All Product");
                Console.WriteLine("3. Find Product with the Highest Unit Price");
                Console.WriteLine("4. View Sales Tax of All Products");
                Console.WriteLine("5. Products to be Ordered");
            }
            static void Add_Product(List<Product> product_list)
            {
            Product p1 = new Product();
            Console.WriteLine("Enter Product Name:");
            p1.product_name = Console.ReadLine();
            Console.WriteLine("Enter Product Category:");
            p1.product_category = Console.ReadLine();
            Console.WriteLine("Enter Product Price:");
            p1.product_price = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Stock Quantity:");
            p1.stock_quantity = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Minimum Stock Quantity:");
            p1.minimum_stock_quantity = int.Parse(Console.ReadLine());
            product_list.Add(p1);

            }

          static void view_products(List<Product> product_list)
        {
            Console.Clear();
            Console.WriteLine("Products:");
            for(int i=0;i<product_list.Count;i++)
            {
                product_list[i].display_product();
            }
        }

        static Product find_highest_price(List<Product> product_list)
        {
            int highest_price = product_list[0].product_price;
            Product Highest_price = product_list[0];
            for(int i=0;i<product_list.Count;i++)
            {
                if(product_list[i].product_price>highest_price)
                {
                    Highest_price = product_list[i];
                }
            }
            return Highest_price;
        }

        static void view_sales_tax(List<Product> product_list)
        {
            int sale_tax = 0;
            foreach(Product i in product_list)
            {
                sale_tax = i.Sales_tax();
                Console.WriteLine(i.product_name + ": Rs. " + sale_tax);
            }
            Console.ReadKey();
        }

        static void product_to_b_ordered(List<Product> product_list)
        {
            Console.Clear();
            foreach(Product i in product_list)
            {
                if(i.IsNeeded())
                {
                    Console.WriteLine(i.product_name);
                }
            }
            Console.ReadKey();
        }
    }

    class Product
    {
        public string product_name;
        public string product_category;
        public int product_price;
        public int stock_quantity;
        public int minimum_stock_quantity;

        public Product()
        {
            product_name = " ";
            product_category = " ";
            product_price = 0;
            stock_quantity = 0;
            minimum_stock_quantity = 0;
        }
        public Product(string pn,string pc,int pp,int sq,int msq)
        {
            product_name = pn;
            product_category = pc;
            product_price = pp;
            stock_quantity = sq;
            minimum_stock_quantity = msq;
        }

        public void display_product()
        {
            Console.WriteLine("Product Name: " + product_name);
            Console.WriteLine("Product Category: " + product_category);
            Console.WriteLine("Product Price: " + product_price);
            Console.WriteLine("Stock Quantity: " + stock_quantity);
            Console.WriteLine("Minimum Stock Quantity: " + minimum_stock_quantity);

        }
        public int Sales_tax()
        {
            int sales_tax=0;
            if(product_category == "Grocery")
            {
                sales_tax = (product_price * 10) / 100;
            }
            else if(product_category == "Fruit")
            {
                sales_tax = (product_price * 5) / 100;

            }
            else
            {
                sales_tax = (product_price * 15) / 100;

            }
            return sales_tax;
        }
         
        public bool IsNeeded()
        {
            bool order = false;
            if(stock_quantity<minimum_stock_quantity)
            {
                order = true;
            }
            return order;
        }

    }

}
