﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using managment_system.bl;

namespace management_system
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            Console.Clear();
            int num_members = 0;
            int num_users = 0;
            List<SignIn> s = new List<SignIn>();
            List<society> soc = new List<society>();

            Readlogindata(s, num_users);
            readmemberdata(soc, num_members);


            int currentSelection = 1;
            while (true)
            {

                displayscreen1();
                subMenuBeforeMainMenu("Login");
                if (currentSelection == 1)
                {
                    Console.Write("  >");
                }
                else
                {
                    Console.Write("   ");
                }
                Console.WriteLine("   Sign Up");
                if (currentSelection == 2)
                {
                    Console.Write("  >");
                }
                else
                {
                    Console.Write("   ");

                }
                Console.WriteLine("   Sign In");
                if (currentSelection == 3)
                {
                    Console.Write("  >");
                }
                else
                {
                    Console.Write("   ");
                }
                Console.WriteLine("   Exit");

                // handle user input

                ConsoleKey keyy = Console.ReadKey().Key;
                if (keyy == ConsoleKey.UpArrow)
                { // up arrow key
                    if (currentSelection > 1)
                    {
                        currentSelection--;
                    }
                    else if (currentSelection == 1)
                    {
                        currentSelection = 3;
                    }
                }

                else if (keyy == ConsoleKey.DownArrow)
                { // down arrow key
                    if (currentSelection < 3)
                    {
                        currentSelection++;
                    }
                    else if (currentSelection == 3)
                    {
                        currentSelection = 1;
                    }
                }

                else if (keyy == ConsoleKey.Enter)
                { // enter key
                    if (currentSelection == 1)
                    {
                        displayscreen1();
                        subMenuBeforeMainMenu("SignUp");
                        signup(s, num_users);
                        Console.ReadKey();
                    }
                    else if (currentSelection == 2)
                    {
                        displayscreen1();
                        subMenuBeforeMainMenu("SignIn");
                        signin(s, soc);
                        Console.ReadKey();
                    }
                    else if (currentSelection == 3)
                    {
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Invalid choice");
                        Console.ReadKey();
                    }
                }
            }
        }

        /* ------------ Sign up/Sign in Menu ----------*/
        static void signup(List<SignIn> s, int num_users)
        {
            SignIn s1 = new SignIn();
            Console.Write("Enter Username:");
            s1.username = Console.ReadLine();
            if (s1.is_username_exist(s1.username, s))
            {
                Console.WriteLine("Username already exists");
                return;
            }

            Console.Write("Enter Password:");
            s1.password = Console.ReadLine();

            int numbb = Console.CursorTop;
        input_phone:
            Console.SetCursorPosition(0, numbb);
            printspace();
            Console.SetCursorPosition(0, numbb);
            Console.Write("Enter Phone Number:");
            s1.contactNumber = Console.ReadLine();
            if (!(s1.isInteger(s1.contactNumber)))
            {
                Console.WriteLine("Invalid input! Please enter a valid Phone Number. ");
                Console.ReadKey();
                goto input_phone;
            }
            if (s1.is_phone_exist(s1.contactNumber, s))
            {
                Console.WriteLine("Phone Number already in use");
                return;
            }

            int numb1 = Console.CursorTop;
        input_email:
            Console.SetCursorPosition(0, numb1);
            printspace();
            Console.SetCursorPosition(0, numb1);
            Console.Write("Enter Email:");
            s1.Email = Console.ReadLine();

            Regex emailRegex = new Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
            if (!(emailRegex.IsMatch(s1.Email)))
            {
                Console.WriteLine("Invalid email address.");
                Console.ReadKey();
                goto input_email;
            }
            if (s1.is_email_exist(s1.Email, s))
            {
                Console.WriteLine("Email already in use");
                return;
            }

            int numb2 = Console.CursorTop;
        input_role:
            Console.SetCursorPosition(0, numb2);
            printspace();
            Console.SetCursorPosition(0, numb2);
            Console.Write("Enter role(admin/student):");
            s1.Role = Console.ReadLine();
            if (!(s1.isString(s1.Role)))
            {
                Console.WriteLine("Invalid input! Please enter a valid Role. ");
                Console.ReadKey();
                goto input_role;
            }

            s.Add(s1);
            Storinglogindata(s1);
            Console.Write("Sign up Successfully");
        }

        static void signin(List<SignIn> s, List<society> soc)
        {
            string option;
            string un, p;
            Console.Write("Enter Username:");
            un = Console.ReadLine();
            Console.Write("Enter Password:");
            p = Console.ReadLine();
            SignIn s1 = new SignIn(un, p);

            if (s1.is_valid_user(s1, s))
            {
                string role1 = s1.get_role(un, s);

                if (role1 == "Admin" || role1 == "admin")
                {
                    Console.WriteLine();
                    Console.WriteLine("        Welcome, " + un + "!");
                    Console.ReadKey();
                    displayscreen();
                    MainMenu();
                    Console.WriteLine("Enter opton: ");
                    option = Console.ReadLine();
                    displayscreen();
                    /*                    AdminsMenu();*/
                    Console.ReadKey();
                }
                else if (role1 == "Student" || role1 == "student")
                {
                    Console.WriteLine("        Welcome, " + un + "!");
                    Console.ReadKey();
                    displayscreen();
                    MainMenu();
                    Console.WriteLine("Enter opton: ");
                    option = Console.ReadLine();
                    displayscreen();
                    StudentMenu(soc, s);
                    Console.ReadKey();

                }
                else
                {
                    Console.WriteLine("Invalid role");
                }
            }
            else
            {
                Console.WriteLine("Incorrect Username or Password");
            }
        }

        /* ------------ Validations ----------*/

      

        /* Menu Functions*/
        static void MainMenu()
        {
            subMenuBeforeMainMenu("Main Menu");
            string option;
            Console.WriteLine("Select the category of the society:");
            Console.WriteLine();
            Console.WriteLine("1.     Sports Societies");
            Console.WriteLine("2.     Programming Societies");
            Console.WriteLine("3.     Creative Art Societies");
            Console.WriteLine("4.     Acedemic Societies");
            Console.WriteLine("5.     Social and Recreational Societies");
            Console.WriteLine("6.     Religious and Spirtual Societies");
            Console.WriteLine("7.     Cultural Societies");
            Console.WriteLine("8.     Artistic Societies");
            Console.WriteLine("9.     Gaming Societies");
            Console.WriteLine("10.    Political or activist Societies");
            Console.WriteLine("11.    Exit");
            Console.WriteLine("Enter option:");
            option = Console.ReadLine();
            Console.WriteLine();

            while (true)
            {
                displayscreen();
                if (option == "1")
                {
                    submenu("Sports Society Menu");
                    SportsSocietyMainMenu();
                }
                else if (option == "2")
                {
                    submenu("Programming Society Menu");
                    ProgrammingSocietiesMainMenu();
                }
                else if (option == "3")
                {
                    submenu("Creative Art Society Menu");
                    CreativeArtSocietiesMainMenu();
                }
                else if (option == "4")
                {
                    submenu("Academic Society Menu");
                    AcademicSocietiesMainMenu();
                }
                else if (option == "5")
                {
                    submenu("Social And Recreational Society Menu");
                    SocialAndRecreationalSocietyMainMenu();
                }
                else if (option == "6")
                {
                    submenu("Religious And Spirual Society Menu");
                    ReligiousAndSpiritualSocietyMainMenu();
                }
                else if (option == "7")
                {
                    submenu("Cultural Society Menu");
                    CulturalSocietiesMainMenu();
                }
                else if (option == "8")
                {
                    submenu("Artistic Society Menu");
                    ArtisticSocietiesMainMenu();
                }
                else if (option == "9")
                {
                    submenu("Gaming Society Menu");
                    GamingSocietiesMainMenu();
                }
                else if (option == "10")
                {
                    submenu("Political Society Menu");
                    PoliticalOrActivistSocietiesMainMenu();
                }
                else if (option == "11")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid choice");
                    Console.ReadKey();
                    displayscreen();
                    MainMenu();
                }
                break;
            }
        }


        static void StudentMenu(List<society> soc, List<SignIn> s)
        {
            submenu("Student Menu");
            string option;
            Console.WriteLine("1.     Register Yourself");
            Console.WriteLine("2.     Update Your Information");
            Console.WriteLine("3.     Remove yourself if you are registered:");
            Console.WriteLine("4.     Display the members of Society");
            Console.WriteLine("5.     Display all the socities ");
            Console.WriteLine("6.     Give a feedback about the society");
            Console.WriteLine("7.     See all the upcoming events");
            Console.WriteLine("8.     Check the reviews about the society");
            Console.WriteLine("9.     Submit a request");
            Console.WriteLine("10.    View the society mission and objectives");
            Console.WriteLine("11.    Donate to the society");
            Console.WriteLine("12.    Exit");
            Console.Write("Enter option:");
            option = Console.ReadLine();
            while (true)
            {
                displayscreen();
                if (option == "1")
                {
                    AddMember(soc, s);
                }
                else if (option == "2")
                {
                    UpdateMember(soc, s);
                }
                else if (option == "3")
                {
                    RemoveMember(soc, s);
                }
                else if (option == "4")
                {
                    DisplayMemberStudent(soc, s);
                }
                else if (option == "5")
                {
                    /*                    displaystudentsociety();*/
                }
                else if (option == "6")
                {
                    /*                    giveFeedback();*/
                }
                else if (option == "7")
                {
                    /*                    displayevent();*/
                }
                else if (option == "8")
                {
                    /*                    displayfeedback();*/
                }
                else if (option == "9")
                {
                    /*                    submitRequest();*/
                }
                else if (option == "10")
                {
                    /*                    displaysocietymission();*/
                }
                else if (option == "11")
                {
                    /*                    donateToSociety();*/
                }
                else if (option == "12")
                {
                    MainMenu();
                    Console.ReadKey();
                    displayscreen();
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid option");
                }
                Console.ReadKey();
                displayscreen();

                break;
            }
        }

        static void AddMember(List<society> soc, List<SignIn> s)
        {
            int currentyu = Console.CursorTop;
            society s1 = new society();
        input_name_again:
            Console.SetCursorPosition(0, currentyu);
            Console.Write("Enter Username: ");
            s1.society_member_username = Console.ReadLine();

            if (!s1.isString(s1.society_member_username))
            {
                Console.WriteLine("Invalid input! Please enter a valid Username.");
                Console.ReadKey(true);
                printspace();
                goto input_name_again;
            }

            int currentyr = Console.CursorTop;

        input_email_again:
            Console.SetCursorPosition(0, currentyr);
            printspace();
            Console.SetCursorPosition(0, currentyr);
            Console.Write("Enter Email: ");
            s1.society_member_email = Console.ReadLine();

            Regex emailRegex = new Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
            if (!(emailRegex.IsMatch(s1.society_member_email)))
            {
                Console.WriteLine("Invalid email address.");
                Console.ReadKey(true);
                goto input_email_again;
            }

            int currentyp = Console.CursorTop;

        input_phone_again:
            Console.SetCursorPosition(0, currentyp);
            Console.Write("Enter Contact Number: ");
            s1.society_member_contact = Console.ReadLine();

            if (!s1.isInteger(s1.society_member_contact))
            {
                Console.WriteLine("Invalid input! Please enter a valid Society Name.");
                Console.ReadKey(true);
                printspace();
                goto input_phone_again;
            }

            if (s1.isString(s1.society_member_username) && s1.isInteger(s1.society_member_contact) && emailRegex.IsMatch(s1.society_member_email))
            {
                /* StoreMemberData(username, email, phone);*/
                soc.Add(s1);
            }

            Console.WriteLine("Press any key to continue...");
            Console.ReadKey(true);
        }

        static void UpdateMember(List<society> soc, List<SignIn> s)
        {
            bool flag = false;
            Console.Write("Enter member's previous username: ");
            string prevUsername = Console.ReadLine();
            Console.Write("Enter member's new username: ");
            string newUsername = Console.ReadLine();

            foreach(society i in soc)
            {
                if (prevUsername == i.society_member_username)
                {
                    i.society_member_username = newUsername;
                    /*                    WriteDataInFile1();*/
                    flag = true;
                }
            }
            if (flag == false)
            {
                Console.WriteLine("Member name not found!");
            }
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey(true);
        }

        static void RemoveMember(List<society> soc, List<SignIn> s)
        {
            bool flag = false;
            Console.Write("Enter Member's name which you want to remove: ");
            string nameToRemove = Console.ReadLine();

            for (int i = 0; i < soc.Count; i++)
            {
                if (nameToRemove == soc[i].society_member_username)
                {
                    soc[i].society_member_username = " ";
                    /*                    WriteDataInFile1();*/
                    flag = true;
                }
            }
            if (flag == false)
            {
                Console.WriteLine("Member name not found!");
            }
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey(true);
        }

        static void DisplayMemberStudent(List<society> soc, List<SignIn> s)
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("Members");

            foreach(society i in soc)
            {
                if (i.society_member_username == " ")
                {
                    continue;
                }

                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(i.society_member_username);
            }
        }
        static void SportsSocietyMainMenu()
        {
            Console.WriteLine("Select any of the given societies: ");
            Console.WriteLine();
            Console.WriteLine("1.     Cricket Club");
            Console.WriteLine("2.     Running Club");
            Console.WriteLine("3.     Athletics Club");
            Console.WriteLine("4.     Vollyball Club");
            Console.WriteLine("5.     Tennis Club");
            Console.WriteLine("6.     Swimming Club");
            Console.WriteLine("7.     Squash Club");
            Console.WriteLine("8.     Running Club");
            Console.WriteLine("9.     Weight Lifting Club");
            Console.WriteLine("10.    Martial Art Society");
            Console.WriteLine("11.    Football Club");
            Console.WriteLine("12.    Badminton Club");
            Console.WriteLine("13.    Basketball Club");
            Console.WriteLine("14.    Hockey Club");
            Console.WriteLine("15.    Cross Country Club");

        }
        static void ProgrammingSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Computer Science Club");
            Console.WriteLine("2.     Coding Society");
            Console.WriteLine("3.     Hacker's Club");
            Console.WriteLine("4.     Programmer's Society");
            Console.WriteLine("5.     Tech Society");
            Console.WriteLine("6.     Software Development Club");
            Console.WriteLine("7.     Web Development Club");
            Console.WriteLine("8.     Mobile Application Development Club");
            Console.WriteLine("9.     Artificial Intelligence Society");
            Console.WriteLine("10.    Cyber Security Club");
            Console.WriteLine("11.    Game Development Club");
        }

        static void CreativeArtSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Photography Club");
            Console.WriteLine("2.     Art Society");
            Console.WriteLine("3.     Film Society");
            Console.WriteLine("4.     Theater Club");
            Console.WriteLine("5.     Creative Writing Society");
            Console.WriteLine("6.     Poetry Club");
            Console.WriteLine("7.     Graphic Design Society");
            Console.WriteLine("8.     Animation Club");
            Console.WriteLine("9.     Fashion Club");
            Console.WriteLine("10.    Craft Society");
        }

        static void AcademicSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Maths Club");
            Console.WriteLine("2.     Science Club");
            Console.WriteLine("3.     Engineering Club");
            Console.WriteLine("4.     Bussiness Club");
            Console.WriteLine("5.     Economics Society");
            Console.WriteLine("6.     Political Science Club");
            Console.WriteLine("7.     Phiosophy Society");
            Console.WriteLine("8.     History Club");
            Console.WriteLine("9.     English Club");
            Console.WriteLine("10.    Literature Society");
            Console.WriteLine("11.    Psychology Club");
            Console.WriteLine("12.    Sociology Club");
            Console.WriteLine("13.    Physics Club");
            Console.WriteLine("14.    Biology Club");
            Console.WriteLine("15.    Chemistry  Club");
        }

        static void SocialAndRecreationalSocietyMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Adventure Club");
            Console.WriteLine("2.     Outdoor Activities Society");
            Console.WriteLine("3.     Travel Club");
            Console.WriteLine("4.     Environmental Club");
            Console.WriteLine("5.     Board Game Society");
            Console.WriteLine("6.     Food Club");
            Console.WriteLine("7.     Human Rights Advocacy Group");
            Console.WriteLine("8.     Student Government Association");
            Console.WriteLine("9.     Debate Club");
            Console.WriteLine("10.    Book Club");
        }

        static void ReligiousAndSpiritualSocietyMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Muslim Student Association");
            Console.WriteLine("2.     Islamic Society");
            Console.WriteLine("3.     Quran Study Group");
            Console.WriteLine("4.     Prayer and Dhikr Circle");
            Console.WriteLine("5.     Da'wah Club");
            Console.WriteLine("6.     Islamic Cultural Society");
            Console.WriteLine("7.     Islamic Education Society");
            Console.WriteLine("8.     Islamic Awareness Society");
            Console.WriteLine("9.     Islamic Finance Society");
            Console.WriteLine("10.     Halaqa(Study Circle)");
        }

        static void CulturalSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     International Student Association");
            Console.WriteLine("2.     African Cultural Society");
            Console.WriteLine("3.     Asian Cultural Society");
            Console.WriteLine("4.     Cultural Society");
            Console.WriteLine("5.     Latin American Cultural Society");
            Console.WriteLine("6.     Middle Eastern Cultural Society");
            Console.WriteLine("7.     Native American Cultural Society");
            Console.WriteLine("8.     Pacific Islander Cultural Society");
            Console.WriteLine("9.     Caribbean Cultural Society");
            Console.WriteLine("10.    South Asian Cultural Society");
            Console.WriteLine("11.    Southeast Asian Cultural Society");
            Console.WriteLine("12.    American Culture Society");
            Console.WriteLine("13.    Australian Cultural Society");
            Console.WriteLine("14.    Canadian Cultural Society");
            Console.WriteLine("15.    New Zealand Cultural Society");
        }

        static void ArtisticSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Photography Club");
            Console.WriteLine("2.     Film Society");
            Console.WriteLine("3.     Drama Club");
            Console.WriteLine("4.     Dance Collective");
            Console.WriteLine("5.     Fine Arts Society");
            Console.WriteLine("6.     Poetry Club");
            Console.WriteLine("7.     Writing Workshop");
            Console.WriteLine("8.     Graphic Design Club");
            Console.WriteLine("9.     Interactive Media Club");
            Console.WriteLine("10.    Digital Art Society");
            Console.WriteLine("11.    Architecture Club");
            Console.WriteLine("12.    Fashion Society");
            Console.WriteLine("13.    Culinary Arts Society");
            Console.WriteLine("14.    Glassblowing Society");
            Console.WriteLine("15.    Performing Arts Society");
        }

        static void GamingSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Esports Club");
            Console.WriteLine("2.     Tabletop Gaming Society");
            Console.WriteLine("3.     Console Gaming Society");
            Console.WriteLine("4.     PC Gaming Society");
            Console.WriteLine("5.     Virtual Reality Club");
            Console.WriteLine("6.     Mobile Gaming Society");
            Console.WriteLine("7.     Retro Gaming Society");
            Console.WriteLine("8.     Adventure Gaming Society");
            Console.WriteLine("9.     Strategy Gaming Society");
            Console.WriteLine("10.    Role-Playing Gaming Society");
            Console.WriteLine("11.    Fighting Game Society");
            Console.WriteLine("12.    Real-Time Strategy Society");
            Console.WriteLine("13.    Survival Gaming Society");
            Console.WriteLine("14.    First-Person Shooter Society");
            Console.WriteLine("15.    Video Game Development Club");
        }

        static void PoliticalOrActivistSocietiesMainMenu()
        {
            Console.WriteLine("Select any of the given societies:\n");
            Console.WriteLine("1.     Student Government Association");
            Console.WriteLine("2.     College Republicans");
            Console.WriteLine("3.     Environmental Action Group");
            Console.WriteLine("4.     Advocacy Society");
            Console.WriteLine("5.     Racial Justice League");
            Console.WriteLine("6.     Economic Justice Alliance");
            Console.WriteLine("7.     Disability Rights Group");
            Console.WriteLine("8.     Animal Rights Society");
            Console.WriteLine("9.     Human Rights Campaign");
            Console.WriteLine("10.    Social Justice Alliance");
            Console.WriteLine("11.    Voter Registration and Advocacy Club");
        }

        /* Display Functions */
        static void printspace()
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 200; j++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
        }

        static void displayscreen()
        {
            Console.Clear();
            USMS();
        }

        static void displayscreen1()
        {
            Console.Clear();
            mainUSMS();
        }

        static void subMenuBeforeMainMenu(string submenu)
        {
            string message = submenu + " Menu";
            Console.WriteLine("             " + message);
            Console.WriteLine("-----------------------------------");
        }

        static void submenu(string submenu)
        {
            string message = " Main Menu > " + submenu;
            Console.WriteLine("             " + message);
            Console.WriteLine("-----------------------------------");
        }

        static void USMS()
        {

            Console.WriteLine("     $$\\   $$\\  $$$$$$\\  $$\\      $$\\  $$$$$$\\  ");
            Console.WriteLine("     $$ |  $$ |$$  __$$\\ $$$\\    $$$ |$$  __$$\\ ");
            Console.WriteLine("     $$ |  $$ |$$ /  \\__|$$$$\\  $$$$ |$$ /  \\__|");
            Console.WriteLine("     $$ |  $$ |\\$$$$$$\\  $$\\$$\\$$ $$ |\\$$$$$$\\  ");
            Console.WriteLine("     $$ |  $$ | \\____$$\\ $$ \\$$$  $$ | \\____$$\\ ");
            Console.WriteLine("     $$ |  $$ |$$\\   $$ |$$ |\\$  /$$ |$$\\   $$ |");
            Console.WriteLine("     \\$$$$$$  |\\$$$$$$  |$$ | \\_/ $$ |\\$$$$$$  |");
            Console.WriteLine("      \\______/  \\______/ \\__|     \\__| \\______/ ");
            Console.WriteLine();

        }
        static void mainUSMS()
        {
            Console.WriteLine("     $$$$$$\\   $$$$$$\\   $$$$$$\\  $$$$$$\\ $$$$$$$$\\ $$$$$$$$\\ $$$$$$\\ $$$$$$$$\\  $$$$$$\\     $$\\   $$\\ $$$$$$$$\\ $$$$$$$$\\ ");
            Console.WriteLine("    $$  __$$\\ $$  __$$\\ $$  __$$\\ \\_$$  _|$$  _____|\\__$$  __|\\_$$  _|$$  _____|$$  __$$\\    $$ |  $$ |$$  _____|\\__$$  __|");
            Console.WriteLine("    $$ /  \\__|$$ /  $$ |$$ /  \\__|  $$ |  $$ |         $$ |     $$ |  $$ |      $$ /  \\__|   $$ |  $$ |$$ |         $$ |   ");
            Console.WriteLine("    \\$$$$$$\\  $$ |  $$ |$$ |        $$ |  $$$$$\\       $$ |     $$ |  $$$$$\\    \\$$$$$$\\     $$ |  $$ |$$$$$\\       $$ |   ");
            Console.WriteLine("    $$\\   $$ |$$ |  $$ |$$ |  $$\\   $$ |  $$ |         $$ |     $$ |  $$ |      $$\\   $$ |   $$ |  $$ |$$ |         $$ |   ");
            Console.WriteLine("    \\$$$$$$  | $$$$$$  |\\$$$$$$  |$$$$$$\\ $$$$$$$$\\    $$ |   $$$$$$\\ $$$$$$$$\\ \\$$$$$$  |$$\\\\$$$$$$  |$$$$$$$$\\    $$ |   ");
            Console.WriteLine("     \\______/  \\______/  \\______/ \\______|\\________|   \\__|   \\______|\\________| \\______/ \\__|\\______/ \\________|   \\__|   ");
            Console.WriteLine();

        }

        /*--------File Handling--------*/

        static void Storinglogindata(SignIn s1)
        {

            string path = "C:\\OOP\\OOP Lab 1\\management system\\login.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(s1.username + "," + s1.password + "," + s1.contactNumber + "," + s1.Email + "," + s1.Role);
            file.Flush();
            file.Close();
        }

        static void Readlogindata(List<SignIn> s, int num_users)
        {
            string path = "C:\\OOP\\OOP Lab 1\\management system\\login.txt";
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    string username = getfile(record, 1);
                    string password = getfile(record, 2);
                    string Email = getfile(record, 3);
                    string contactNumber = getfile(record, 4);
                    string Role = getfile(record, 5);
                    SignIn info = new SignIn(username,password,Email,contactNumber,Role);
                    s.Add(info);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Not Exists");
            }
        }

        static string getfile(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }

        static void storememberdata(string mu, string me, string mp)
        {
            string path = "C:\\OOP\\OOP Lab 1\\management system\\memberdata.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(mu + "," + me + "," + mp);
            file.Flush();
            file.Close();
        }

        static void readmemberdata(List<society> soc, int num_members)
        {
            string path = "C:\\OOP\\OOP Lab 1\\management system\\memberdata.txt";
            if (File.Exists(path))
            {
                StreamReader file = new StreamReader(path);
                string record;
                while ((record = file.ReadLine()) != null)
                {
                    society so = new society();
                    so.society_member_username = getfile(record, 1);
                    so.society_member_contact = getfile(record, 2);
                    so.society_member_email = getfile(record, 3);
                    soc.Add(so);
                }
                file.Close();
            }
            else
            {
                Console.WriteLine("Not exists");
            }
        }
    }
}

