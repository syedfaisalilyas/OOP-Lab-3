﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace managment_system.bl
{
    class SignIn
    {
            public string username;
            public string password;
            public string contactNumber;
            public string Email;
            public string Role;
        public SignIn()
        {
            
        }
        public SignIn(string username ,string password)
        {
            this.username = username;
            this.password = password;
        }
        public SignIn(string username ,string password, string contactNumber,string Email,string Role)
        {
            this.username = username;
            this.password = password;
            this.contactNumber = contactNumber;
            this.Email = Email;
            this.Role = Role;
        }

        public bool is_valid_user(SignIn s1, List<SignIn> s)
        {
            foreach(SignIn i in s)
            {
                if (i.username == s1.username && i.password == s1.password)
                {
                    return true;
                }
            }
            return false;
        }

        public string get_role(string un, List<SignIn> s)
        {
            for (int i = 0; i < s.Count; i++)
            {
                if (s[i].username == un)
                {
                    return s[i].Role;
                }
            }
            return "";
        }
        public bool is_username_exist(string usern, List<SignIn> s)
        {
            foreach(SignIn i in s)
            {
                if (usern == i.username)
                {
                    return true;
                }
            }
            return false;
        }

      public bool is_phone_exist(string phonen, List<SignIn> s)
        {
            foreach(SignIn i in s)
            {
                if (phonen == i.contactNumber)
                {
                    return true;
                }
            }
            return false;
        }

        public bool is_email_exist(string em, List<SignIn> s)
        {
            foreach(SignIn i in s)
            {
                if (em == i.Email)
                {
                    return true;
                }
            }
            return false;
        }
        public bool isString(string str)
        {

            for (int i = 0; i < str.Length; i++)
            {
                if ((!char.IsLetter(str[i])) && str[i] != ' ')
                {
                    return false;
                }
            }
            return true;
        }
        public bool isInteger(string str)
        {

            for (int i = 0; i < str.Length; i++)
            {
                if ((!char.IsDigit(str[i])) && str[i] != ' ')
                {
                    return false;
                }
            }
            return true;
        }

        


    }
    class society
    {
        public string society_member_username;
        public string society_member_email;
        public string society_member_contact;

        public society()
        {

        }
        public society(string society_member_username, string society_member_email, string society_member_contact)
        {
            this.society_member_username = society_member_username;
            this.society_member_email = society_member_email;
            this.society_member_contact = society_member_contact;
        }
        public bool isString(string str)
        {

            for (int i = 0; i < str.Length; i++)
            {
                if ((!char.IsLetter(str[i])) && str[i] != ' ')
                {
                    return false;
                }
            }
            return true;
        }
        public bool isInteger(string str)
        {

            for (int i = 0; i < str.Length; i++)
            {
                if ((!char.IsDigit(str[i])) && str[i] != ' ')
                {
                    return false;
                }
            }
            return true;
        }

    }

}

